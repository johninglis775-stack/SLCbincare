# South Lanarkshire Bin Care — Phase 0 Landing Page

## What this is
A static HTML/CSS/JS landing page to announce the service and collect interest.

## How to run locally
Just open `index.html` in your browser.

## To deploy
Upload the folder to a static host (Netlify / Cloudflare Pages / GitHub Pages) and connect your domain.

## Next steps (Phase 1+)
- Replace placeholder social links with real ones
- Replace placeholder email with Google Workspace address
- Switch the form from mailto fallback to a form endpoint (Netlify Forms, Formspree, etc.)
- Add QR code pointing to the domain once purchased